import boto3
from botocore.exceptions import ClientError


AMI = 'ami-03fa4afc89e4a8a09'
#INSTANCE_TYPE = 't2.micro'
#KEY_NAME = 'VenkatTomcat'
REGION = 'ap-south-1'

#ec2 = boto3.client('ec2', region_name=REGION)

def lambda_handler(event, context):
    ec2 = boto3.client('ec2', region_name=REGION)
    instance=ec2.run_instances(
            ImageId=AMI,
            MinCount=1,
            MaxCount=1,
            InstanceType='t2.micro',
            KeyName='VenkatTomcat'
            )
    print ("New instance created:")
    instance_id = instance['Instances'][0]['InstanceId']
    print (instance_id)
    #ec2.create_tags(Resources=['instance_id'], Tags=[{'Key':'Name', 'Value':'Lambda_function'}])
    return instance_id


def lambda_handler(event, context):
    responce = boto3.client('iam', region_name=REGION)
    accountId = event['AccountId']
    role_name = event['RoleName']

    policy_json = {
            "version" : "2012-10-17",
            "Statement" : [{
                "Effect": "Allow",
                "Action": [
                    "secretsmanager:*"
                    ],
                "Resource": "*"
                }]
            }
    try:
        policy_res = iam_client.create_policy(
                PolicyDocument=json.dumps(policy_json)
        )
        policy_arn = policY_res['Policy']['Arn']
    except ClientError as error:
        policy_arn = 'arn:aws:iam::' + account_id + ':policy/' + policy_name

    try:
        policy_attach_res = iam_client.attach_role_policy(
                RoleName = role_name,
                PolicyArn = policy_arn
        )
    except ClientError as error:
        iam_client.delete_role(
                RoleName = role_name
        )

    return "success"
